package com.example.daltonismo

data class TesteDownto(var resp1:String, var resp2:String, var resp3:String) {
}